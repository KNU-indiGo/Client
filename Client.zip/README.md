# indiGo
LG-WebOS internship project

Notion link: https://www.notion.so/LG-193ad80b546749a3aa8438ac6af718d3



<!-- ### Prerequisites -->

<!-- ## Running / 실행

어떻게 테스트가 이 시스템에서 돌아가는지에 대한 설명을 합니다

### 테스트는 이런 식으로 동작합니다

왜 이렇게 동작하는지, 설명합니다

```
예시
``` -->

<!-- ## Codes -->
## Version Control
* 2021.06.21 Started project

## Contributors

* [pinkishincoloragain](https://github.com/pinkishincoloragain)
* [Go-Jaecheol](https://github.com/Go-Jaecheol)
* [choi-jaewon](https://github.com/choi-jaewon)
* [nullyng](https://github.com/nullyng)
* [ParkGyurim99](https://github.com/ParkGyurim99)

<!-- ## Acknowledgments -->

<!-- *  -->
